#!/bin/sh
 
MNT_PATH=/mnt

MNT_DIR=
SD1_DIR=sda
SD2_DIR=sd2
SD3_DIR=sd3
EMMC1_DIR=emmc1
EMMC2_DIR=emmc2
CACHE_DIR=cache
DRIVE_A=""
DRIVE_B=""

my_umount()
{
	FOLDER=`grep "/dev/$1" /proc/mounts | cut -d ' ' -f 2`
	if [ ! -z "$FOLDER" ]; then
		umount -l "$FOLDER";
	fi
}
 
my_mount()
{
	MMCBUSNUM=`echo $DEVPATH | cut -d '/' -f 4`
	if [ "$MMCBUSNUM" == "nt96660_mmc.0" ] || [ "$MMCBUSNUM" == "f0420000.mmc" ]; then
		MNT_DIR=$SD1_DIR
	elif [ "$MMCBUSNUM" == "nt96660_mmc.1" ] || [ "$MMCBUSNUM" == "f0500000.mmc" ]; then
		MNT_DIR=$SD2_DIR
	else
		MNT_DIR=$SD3_DIR
	fi

	if [ -b /dev/$1 ]; then
		MOUNTDEV="/dev/$1"
		if [ -b "/dev/$1p1" ]; then
			MOUNTDEV="/dev/$1p1"
		fi
	fi	

	time_offset_sig=`date +%z | cut -c 1`
	time_offset_h=`date +%z | cut -c 2-3`
	time_offset_m=`date +%z | cut -c 4-5`
	time_offset=`expr $local_time - $utc_time`
	if [ $time_offset_sig == + ]; then
		time_offset_sig="";
	fi
	time_offset_total_m=$time_offset_sig`expr $time_offset_h \* 60 + $time_offset_m`
	
	mkdir -p "${MNT_PATH}/${MNT_DIR}" || exit 1
	fat_type=`blkid "$MOUNTDEV" | awk -F'TYPE=' '{print $NF}'`
	if [ "${fat_type}" == "\"vfat\"" ]; then
		if ! mount -o dirsync,time_offset=$time_offset_total_m "$MOUNTDEV" "${MNT_PATH}/${MNT_DIR}" 2>&1 | tee -a /tmp/mountstat; then
			echo "$MOUNTDEV $MNT_PATH/$MNT_DIR ignore defaults 0 0" >> /tmp/.nvt_mounts
			exit 1
		fi
	elif [ "${fat_type}" == "\"exfat\"" ]; then
		if ! mount -t exfat "$MOUNTDEV" "${MNT_PATH}/${MNT_DIR}" 2>&1 | tee -a /tmp/mountstat; then
			echo "$MOUNTDEV $MNT_PATH/$MNT_DIR ignore defaults 0 0" >> /tmp/.nvt_mounts
			continue
		fi
	else
		echo "$MOUNTDEV FAIL" >> /tmp/.nvt_mounts
		exit 1
	fi
}

check_mmc_ready()
{
	MMCBUSPATH="/sys/bus/mmc/devices/"
	x=0
	timeout=100
	echo "check_mmc_ready"
	while [ "$x" -lt "$timeout" -a ! -d $MMCBUSPATH ]; do
		echo "MMCBUSPATH is not exist."
		x=$((x+1))
		sleep .1
	done
	if [ "$x" -ge "$timeout" ]; then
		echo "check_mmc_ready timeout"
		return  -1;
	fi
	echo "MMCBUSPATH:$MMCBUSPATH"
	return 0;
}

create_link()
{
	if [ -b /dev/$1 ]; then
		echo dev=$1
		if [ -d "/dev/hd/" ];then
			rm -rf /dev/hd/
		fi
		mkdir -p /dev/hd/
		ln -s /dev/$1 /dev/hd/sda
		for part in $(ls /dev/$1p*)
		do
		if [ -b $part ]; then
			ln -s $part /dev/hd/sda1
			break;
		fi
		done
	fi	
}

remove_link()
{
	rm -rf /dev/hd
}



if [ -z $DEVPATH ]; then
	# This is for boot stage handling
	MMCBUSPATH="/sys/bus/mmc/devices/"
	check_mmc_ready
	ret=$?
	if [ $ret != 0 ]; then
		echo "MMCBUSPATH exist"
		exit;
	fi
	
	MMCDEVLIST=`ls $MMCBUSPATH`

	for n in $MMCDEVLIST
	do
		# Check if it is not SD device
		SD_TYPE=`cat $MMCBUSPATH/$n/type`
		echo "SD_TYPE:$SD_TYPE"
		if [ $SD_TYPE == SDIO ]; then
			continue
		fi

		if [ $SD_TYPE == MMC ]; then
			# To check if it's the emmc storage device
			if [ -f $MMCBUSPATH/$n/bga ]; then
				BGA=`cat $MMCBUSPATH/$n/bga`
				if [ 1 == $BGA ]; then
					# Get the block device name
					BLOCKDEV=`ls $MMCBUSPATH/$n/block`
					create_link $BLOCKDEV
				fi
			fi
			continue
		fi

		# Get the block device name
		BLOCKDEV=`ls $MMCBUSPATH/$n/block`
		if [ -b /dev/$BLOCKDEV ]; then
			create_link $BLOCKDEV
		else
			continue
		fi
	done
else
	# This is for booted up stage
	case "${ACTION}" in
	add|"")
		remove_link 
		create_link ${MDEV}
		;;
	remove)
		remove_link 
		;;
	esac
fi
